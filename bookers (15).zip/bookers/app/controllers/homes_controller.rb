class HomesController < ApplicationController
  def root
  end
 
end
